---
name: email-proxy
description: "Send and receive emails through Polsia's authenticated email proxy endpoints."
---

# Email Proxy

Send and receive emails using Polsia's email proxy. Every company gets `{slug}@polsia.app`.

## Base URL

```
https://polsia.com/api/proxy/email
```

## Authentication

```javascript
headers: {
  Authorization: `Bearer ${process.env.POLSIA_API_KEY}`,
}
```

The API key must start with `company_`. It is auto-provisioned as `POLSIA_API_KEY` in deployed apps.

## Send Email

```javascript
await fetch('https://polsia.com/api/proxy/email/send', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${process.env.POLSIA_API_KEY}`,
  },
  body: JSON.stringify({
    to: 'user@example.com',
    subject: 'Hello',
    body: 'Plain text content (required)',
    html: '<p>HTML content</p>', // Optional: HTML version
    reply_to_email_id: 123, // Optional: pass inbound email ID to bypass rate limit
  }),
});
```

**Important:** Use `body` (not `text_body`) for sending. The `html` field is optional but recommended for formatted emails like magic links.

**Important:** The only accepted parameters are `to`, `subject`, `body`, `html`, and `reply_to_email_id`. Do not pass any other parameters.

## Read Inbox

```javascript
const res = await fetch('https://polsia.com/api/proxy/email/inbox', {
  headers: { Authorization: `Bearer ${process.env.POLSIA_API_KEY}` },
});
const { emails } = await res.json();
// Each email has an 'id' - use it as reply_to_email_id when replying
```

## Inbound Email Webhook

Emails to `{slug}@polsia.app` trigger your `/api/webhook/email` endpoint:

```javascript
app.post('/api/webhook/email', async (req, res) => {
  // Note: Inbound emails use text_body/html_body (different from send API)
  const { from, subject, text_body, html_body, email_id } = req.body;

  // Process the email...

  // Reply (bypasses rate limit):
  // Note: Send API uses body/html (not text_body/html_body)
  await fetch('https://polsia.com/api/proxy/email/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.POLSIA_API_KEY}`,
    },
    body: JSON.stringify({
      to: from,
      subject: `Re: ${subject}`,
      body: 'Thanks for your email!', // Use 'body' not 'text_body'
      html: '<p>Thanks for your email!</p>', // Optional HTML version
      reply_to_email_id: email_id, // Bypasses rate limit
    }),
  });

  res.json({ success: true });
});
```

**Field name reference:**
| Direction | Text field | HTML field |
|-----------|------------|------------|
| Sending (POST /send) | `body` | `html` |
| Receiving (webhook) | `text_body` | `html_body` |

## Rate Limits

Email classification is determined **server-side**. You do not need to pass any flags.

| Type                               | Limit     | How it's determined             |
| ---------------------------------- | --------- | ------------------------------- |
| Replies to inbound emails          | Unlimited | Pass `reply_to_email_id`        |
| All other sends from deployed apps | 50/day    | Automatic (tunable via env var) |

API returns 429 error if limit exceeded.

### Transactional emails (OTPs, password resets, notifications)

Transactional emails are handled automatically. The email proxy classifies all non-reply sends from deployed apps under the known-contact tier (50/day), not the cold outreach tier (2/day). No special flags are needed. Just send the email normally:

```javascript
// OTP email - just send it, no special flags needed
await fetch('https://polsia.com/api/proxy/email/send', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${process.env.POLSIA_API_KEY}`,
  },
  body: JSON.stringify({
    to: 'newuser@example.com',
    subject: 'Your verification code',
    body: 'Your OTP code is: 123456',
  }),
});
```

## Register Contacts

Register users from your app (on signup, contact form submission, purchase, etc.) so they are recognized as known contacts. This is the recommended way to ensure transactional emails to your users are never rate-limited on the agent path.

```javascript
// Call this on signup, contact form, purchase, or any user-creation event
await fetch('https://polsia.com/api/proxy/email/contacts', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${process.env.POLSIA_API_KEY}`,
  },
  body: JSON.stringify({
    email: 'newuser@example.com',
    name: 'Jane Doe', // optional
    source: 'signup', // required: signup | contact_form | purchase | invite | import | other
  }),
});
```

Register the contact **before** sending them emails. Once registered, the contact gets known-contact treatment across all email paths (proxy and agent).

## Common Errors

| Status | Code                     | Cause                             | Fix                                                 |
| ------ | ------------------------ | --------------------------------- | --------------------------------------------------- |
| 401    | `missing_api_key`        | No Authorization header           | Add `Bearer ${POLSIA_API_KEY}` header               |
| 401    | `invalid_api_key_format` | Key doesn't start with `company_` | Use the auto-provisioned `POLSIA_API_KEY`           |
| 404    | Not found                | Wrong URL                         | Use `/api/proxy/email/send` (not `/api/email/send`) |
| 429    | `*_limit_exceeded`       | Daily rate limit hit              | Wait until tomorrow or connect your own email       |

## DO NOT

- Set up separate email services (SendGrid, Postmark, etc.)
- Use the company's own SMTP credentials
- Build custom email infrastructure
- Pass undocumented parameters (e.g., `transactional`) — they are silently ignored

Use the Polsia email proxy - it's already configured for your company.
